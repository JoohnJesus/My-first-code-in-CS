using System;

class Program {
  public static void Main (string[] args) {

String nome = "";
String sobrenome = "";
    
Console.Write ("Qual o seu nome? ");
nome = Console.ReadLine();
    
Console.Write ("Qual o sobrenome? ");
sobrenome = Console.ReadLine();

    
    Console.WriteLine("Seja bem vindo(a) "+ nome + " " + sobrenome + "!");
  }
}